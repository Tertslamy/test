# basic-islamic-inheritance-calculator
live demo https://inheritance-calculator.netlify.com/